# DATOS GENERALES

**UUID**: 4f05b5b4-a571-44ea-b3b8-71612a03f6a0

**Nombre constructor**: M.plugin.Areainfluencia

**Origen**: NTT DATA

**Descripción**: Plugin encargado de proporcionar el porcentaje de los objetos de una capa que se encuentren dentro de una determinada área de influencia.

**Uso de OpenLayers**: -


# VERSIONES

VERSION | D_DESCRIPCION | T_NUMERO_VERSION | C_UUID
-- | -- | -- | --
1.0.0 | PLG-GEOINFLUENCIA - Versión 1.0.0 | 1.0.0 | 90822a61-8a68-4eba-b1a3-ef13e0646704
1.1.0 | PLG-GEOINFLUENCIA - Versión 1.1.0 | 1.1.0 | ce1e9803-6f7a-40fe-9971-239a2d3268a2
1.2.0 | PLG-GEOINFLUENCIA - Versión 1.2.0 | 1.2.0 | 97fb15c6-0d2a-404b-a2ff-4d6b709e6aa6
1.2.1 | PLG-GEOINFLUENCIA - Versión 1.2.1 | 1.2.1 | 047cdd1f-b08b-459e-9492-498c3efdc4b2
1.3.0 | PLG-GEOINFLUENCIA - Versión 1.3.0 | 1.3.0 | c2f12df9-83be-4a6c-ac87-67dba419a9fe

## Tabla de compatibilidades

VERSION DEL PLUGIN | VERSION DE MAPEA
-- | --
1.0.0 | 5.2.0
1.1.0 | 6.2.0
1.2.0 | 6.2.0
1.2.1 | 6.2.0
1.3.0 | 5.1.0, 5.2.0, 6.0.0, 6.1.0, 6.2.0, 6.3.0

# RECURSOS

VERSION | T_NOMBRE_RECURSO | T_TIPO | T_URL | C_UUID
-- | -- | -- | -- | --
1.0.0 | PLG-GEOINFLUENCIA - Versión 1.0.0 - Recurso JS | JS | plugins/plg_geoinfluencia/1.0.0/areainfluencia.ol.min.js | 54fab38b-52dd-4b09-a059-f92ab29493ad
1.0.0 | PLG-GEOINFLUENCIA - Versión 1.0.0 - Recurso JS - Plugin Buffer | JS | plugins/plg_geoinfluencia/1.0.0/buffer.ol.min.js | 742137ac-3876-46ff-b390-e276a870f993
1.0.0 | PLG-GEOINFLUENCIA - Versión 1.0.0 - Recurso CSS | CSS | plugins/plg_geoinfluencia/1.0.0/areainfluencia.ol.min.css | e3ff5af2-e0e4-42ba-91fe-698e0a262ed2
1.1.0 | PLG-GEOINFLUENCIA - Versión 1.1.0 - Recurso JS | JS | plugins/plg_geoinfluencia/1.1.0/areainfluencia.ol.min.js | 3a610694-39cc-41e3-a96a-2dc70398b325
1.1.0 | PLG-GEOINFLUENCIA - Versión 1.1.0 - Recurso JS - Plugin Buffer | JS | plugins/plg_geoinfluencia/1.1.0/buffer.ol.min.js | 4a401bfe-8450-4ab8-9200-a9b2ba94ebf3
1.1.0 | PLG-GEOINFLUENCIA - Versión 1.1.0 - Recurso CSS | CSS | plugins/plg_geoinfluencia/1.1.0/areainfluencia.ol.min.css | d25a4454-ceba-4e92-8a1b-a4e47e76ed14
1.1.0 | PLG-GEOINFLUENCIA - Versión 1.1.0 - Recurso JSON | JSON | plugins/plg_geoinfluencia/1.1.0/api.json | 801d5755-c765-46be-b0d3-4263f4e31b4c
1.2.0 | PLG-GEOINFLUENCIA - Versión 1.2.0 - Recurso JS | JS | plugins/plg_geoinfluencia/1.2.0/areainfluencia.ol.min.js | f04866ea-a899-49d4-832a-d2a059023160
1.2.0 | PLG-GEOINFLUENCIA - Versión 1.2.0 - Recurso JS - Plugin Buffer | JS | plugins/plg_geoinfluencia/1.2.0/buffer.ol.min.js | 2f368666-810c-487f-ba08-d5a172fcee23
1.2.0 | PLG-GEOINFLUENCIA - Versión 1.2.0 - Recurso CSS | CSS | plugins/plg_geoinfluencia/1.2.0/areainfluencia.ol.min.css | 9531cad2-751c-4b89-9e7f-38dbc036b7ce
1.2.0 | PLG-GEOINFLUENCIA - Versión 1.2.0 - Recurso JSON | JSON | plugins/plg_geoinfluencia/1.2.0/api.json | 7f9e9c55-bb42-4a92-a537-798bdf4b9309
1.2.1 | PLG-GEOINFLUENCIA - Versión 1.2.1 - Recurso JS | JS | plugins/plg_geoinfluencia/1.2.1/areainfluencia.ol.min.js | a7d882d6-6615-4978-988c-b9220b6a4e76
1.2.1 | PLG-GEOINFLUENCIA - Versión 1.2.1 - Recurso JS - Plugin Buffer | JS | plugins/plg_geoinfluencia/1.2.1/buffer.ol.min.js | 9bd5bf52-109c-4a6d-88c3-593c6db4a7ed
1.2.1 | PLG-GEOINFLUENCIA - Versión 1.2.1 - Recurso CSS | CSS | plugins/plg_geoinfluencia/1.2.1/areainfluencia.ol.min.css | 478275e5-3807-4020-adb7-b40b69d4f8c6
1.2.1 | PLG-GEOINFLUENCIA - Versión 1.2.1 - Recurso JSON | JSON | plugins/plg_geoinfluencia/1.2.1/api.json | 4f7a39e4-a67d-4a10-b01a-88cbbffa1a15
1.3.0 | PLG-GEOINFLUENCIA - Versión 1.3.0 - Recurso JS | JS | plugins/plg_geoinfluencia/1.3.0/areainfluencia.ol.min.js | 258040a5-3969-4b87-b5f4-a07dbf6011d4
1.3.0 | PLG-GEOINFLUENCIA - Versión 1.3.0 - Recurso JS - Plugin Buffer | JS | plugins/plg_geoinfluencia/1.3.0/buffer.ol.min.js | 3ce9c934-9ffc-4374-9765-3b5638f10239
1.3.0 | PLG-GEOINFLUENCIA - Versión 1.3.0 - Recurso CSS | CSS | plugins/plg_geoinfluencia/1.3.0/areainfluencia.ol.min.css | d90ada43-0e62-4643-91d9-04f80cdc90d0
1.3.0 | PLG-GEOINFLUENCIA - Versión 1.3.0 - Recurso JSON | JSON | plugins/plg_geoinfluencia/1.3.0/api.json | 4c31a873-1ed8-4386-b838-065f998a185e

# PARÁMETROS

NOMBRE | DESCRIPCIÓN | VALOR | ESPECIFICACIONES
-- | -- | -- | --
apliGeoprontelUrl | Indica la URL de la API de Geoprontel | 'https://www.juntadeandalucia.es/medioambiente/serviciosGeoprontel/geoproceso’ | Texto/ obligatorio
layerIds | Identificadores de las capas que buscará Geoprontel para conocer el área de influencia | 'campamentos' | Texto/ obligatorio
otherUrlsToGeoprontel | Otras URLs que se consultarán con Geoprontel |       ['https://www.juntadeandalucia.es/medioambiente/mapwms/REDIAM_WFS_Patrimonio_Natural?service=WFS&request=getFeature&version=2.0.0&outputformat=geojson&typename=humedales_ramsar'] | Texto/ opcional
locationUrls | Urls de localización. “PART_X” se sustituirá por la coordenada X y “PART_Y” se sustituirá por la coordenada Y, deben utilizar el mismo sistema de referencia que el mapa y ser peticiones GET | ['https://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR?Coordenada_X=PART_X&Coordenada_Y=PART_Y&SRS=EPSG:25830'], | Texto/ opcional
catastrowfsurl | URL que contiene los datos de la capa WFS de Catastro. Se debe introducir si en el array ‘locationUrls’ se encuentra alguna URL que contenga la cadena de texto ‘catastro’ | ‘http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?’ | Texto/ opcional
 


# INSTANCIACIÓN

## INSTANCIACIÓN COMO PLUGIN

```
const mp = new M.plugin.Areainfluencia({
  apiGeoprontelUrl: 'https://www.juntadeandalucia.es/medioambiente/serviciosGeoprontel/geoproceso',
  layerIds: ['campamentos'],
  locationUrls: [],
  otherUrlsToGeoprontel: []
});

map.addPlugin(mp);
```

## INSTANCIACIÓN MEDIANTE BARRA DE NAVEGACIÓN

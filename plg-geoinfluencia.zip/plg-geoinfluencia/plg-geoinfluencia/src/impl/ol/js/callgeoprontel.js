export default class CallGeoprontel {
    static getRenderedFeatures(bufferLayer) {
        return bufferLayer.getImpl().layerOL.getSource().getFeatures();//getRenderer().renderedFeatures_;
    }
}
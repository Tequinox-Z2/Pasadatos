import M$plugin$Areainfluencia from 'C:/git/PLG-GEOINFLUENCIA/src/facade/js/areainfluencia';
import M$control$AreainfluenciaControl from 'C:/git/PLG-GEOINFLUENCIA/src/facade/js/areainfluenciacontrol';
import M$impl$control$AreainfluenciaControl from 'C:/git/PLG-GEOINFLUENCIA/src/impl/ol/js/areainfluenciacontrol';

if (!window.M.plugin) window.M.plugin = {};
if (!window.M.control) window.M.control = {};
if (!window.M.impl) window.M.impl = {};
if (!window.M.impl.control) window.M.impl.control = {};
window.M.plugin.Areainfluencia = M$plugin$Areainfluencia;
window.M.control.AreainfluenciaControl = M$control$AreainfluenciaControl;
window.M.impl.control.AreainfluenciaControl = M$impl$control$AreainfluenciaControl;

import CallGeoprontelImpl from 'impl/callgeoprontel';

let aux = false;

let selectedLayerIds=[];

const filters = {
    sipna:'<Filter xmlns="http://www.opengis.net/ogc" xmlns:gml="http://www.opengis.net/gml"><Intersects><PropertyName>geom</PropertyName><gml:Polygon srsName="EPSG:25830"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>BBOX</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></Intersects></Filter>',
    agriculturaypesca: '<Filter xmlns="http://www.opengis.net/ogc" xmlns:gml="http://www.opengis.net/gml"><Intersects><PropertyName>SD_GEOM</PropertyName><gml:Polygon srsName="EPSG:25830"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>BBOX</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></Intersects></Filter>'
};

export default class CallGeoprontel {
    static putEvents(map, apiGeoprontelUrl, layerIds, otherUrlsToGeoprontel, locationUrls, catastrowfsurl) {
        map.getMapImpl().on('click', () => {
            this.preparePlugin(map, apiGeoprontelUrl, layerIds, otherUrlsToGeoprontel, locationUrls, catastrowfsurl);
        });

        map.on(M.evt.CLICK, () => {
            this.preparePlugin(map, apiGeoprontelUrl, layerIds, otherUrlsToGeoprontel, locationUrls, catastrowfsurl);
        });
        
        // Se pone evento en el mapa para ponerlo en el botón “OK” de la creación del “buffer”
        map.getMapImpl().on('dblclick', () => {
            this.preparePlugin(map, apiGeoprontelUrl, layerIds, otherUrlsToGeoprontel, locationUrls, catastrowfsurl);
        });         
    }

    static preparePlugin(map, apiGeoprontelUrl, layerIds, otherUrlsToGeoprontel, locationUrls, catastrowfsurl) {
        if(document.getElementById('remove') && !aux) {
            document.getElementById('remove').addEventListener('click', () => {
                if (document.getElementById('table')) {
                    document.getElementById('table').remove();
                }
                if (document.getElementById('toggle-button')) {
                    document.getElementById('toggle-button').remove();
                }
            });
            aux = true;
        }
        if (document.getElementsByClassName('m-button').length > 0 && document.getElementsByClassName('m-title').length > 0 ) {
            const classElements = document.getElementsByClassName('m-title');
            for(let x = 0; x < classElements.length; x++) {
                if(classElements[x].children.length > 1 && classElements[x].children[1].innerText === 'ÁREA DE INFLUENCIA') {
                    setTimeout(this.getAreaInformation.bind(this), 100, map, apiGeoprontelUrl, layerIds, otherUrlsToGeoprontel, locationUrls, classElements[x].parentElement, catastrowfsurl);
                    break;
                }
            }  

            var myEle = document.getElementById("buttonCancel");
            if (myEle===null) {
                //Añadir botón de cancelar
                const buttElement = document.getElementsByClassName('m-content');
                //Crear botón
                var tempButt = document.createElement("BUTTON");
                tempButt.id = "buttonCancel";
                tempButt.innerHTML = "Cancelar";  
                tempButt.style.width="auto";
                if (buttElement.length === 1){
                    buttElement[0].children[2].insertAdjacentElement('beforeend', tempButt);

                } else{
                    //Solución cuando sale doble popup
                    buttElement[1].children[2].insertAdjacentElement('beforeend', tempButt);
                }

                //Funcionalidad botón cancelar
                if(document.getElementById('buttonCancel')) {
                    document.getElementById('buttonCancel').addEventListener('click', () => {
                        if (document.getElementsByClassName('m-dialog')[0]) {
                            document.getElementsByClassName('m-dialog')[0].remove();
                        }
                        //ELIMINAR geometría
                        var obtenerPlg = map.getPlugins();
                        for (let i = 0; i < obtenerPlg.length; i++) {
                            if (obtenerPlg[i].name === 'buffer') {
                                obtenerPlg[i].control_.removeFeatures();
                            }
                        }

                    });
                }
            }

        }

        // if(layerIds.length !== 0){
        if(layerIds !== undefined && layerIds.length !== 0){
          //añadir selector múltiple
          var selMul = document.getElementById("capaSelect");
          if (selMul===null) {
              const messageElement = document.getElementsByClassName('m-message');
              for(let x = 0; x < messageElement.length; x++) {
                  //Crear etiqueta de información
                  var tempLab = document.createElement('div');
                  tempLab.setAttribute("id", "labelSelect");
                  tempLab.setAttribute("class", "m-getdata-select");
                  messageElement[x].children[0].insertAdjacentElement('beforeend', tempLab);
                  document.getElementById("labelSelect").style.width="100%";
                  document.getElementById("labelSelect").style.paddingTop = "0.5rem";
  
                  //Crear div de selección
                  var tempDiv = document.createElement('div');
                  tempDiv.setAttribute("id", "capaSelect");
                  tempDiv.setAttribute("class", "m-getdata-select");
                  messageElement[x].children[0].insertAdjacentElement('beforeend', tempDiv);
                  document.getElementById("capaSelect").style.width="100%";
  
                  // Crear objeto de tipo select multiple
                  var selectList = document.createElement("select");
                  selectList.id = "selectedID";
                  selectList.multiple="multiple";
                  tempDiv.appendChild(selectList);  
                  document.getElementById("selectedID").style.width="100%";    
  
                  //Comparación de las capas en el mapa con la capa del parámetro layerIds.
                  const layers = map.getLayers();
                  var resultSelect = [];
                  for (let i = 0; i < layers.length; i++) {
                      const element = layers[i];
                      for (let j = 0; j < layerIds.length; j++) {
                          const element2 = layerIds[j];
                          if (element.name === element2) {
                              resultSelect.push(element.name);
                          } 
                      }
                  }
  
                  var tempOpt = document.createElement("OPTION"); 
                  tempOpt.innerHTML = ("Seleccione capa(s):");
                  tempOpt.style.fontWeight="bold";   
                  selectList.appendChild(tempOpt);
  
                  // Una vez comparado, se rellenará con los nombres de las capas 
                  resultSelect.forEach(element => {
                      var tempOpt = document.createElement("OPTION"); 
                      tempOpt.innerHTML = element;  
                      selectList.appendChild(tempOpt);                    
                  });
              
                  //resultado opción selectedLayerIds
                  const optSelect = document.getElementById('selectedID'); 
                  optSelect.addEventListener('change', (e) => {
  
                      const options = e.target.options;
                      const selectedOptions = [];
                      const selectedValues = [];
                  
                      for (let i = 0; i < options.length; i++) {
                      if (options[i].selected) {
                          selectedOptions.push(options[i]);
                          selectedValues.push(options[i].value);
                      }
                      }
                  
                      selectedLayerIds = selectedValues;
                      return selectedValues;
  
                  });
              }
          }   
        }
 

    }

    static getAreaInformation(map, apiGeoprontelUrl, layerIds, otherUrlsToGeoprontel, locationUrls, divElement, catastrowfsurl) {
        divElement.getElementsByClassName('m-title')[0].style.backgroundColor = '#007a33';
        divElement.getElementsByClassName('m-button')[0].children[0].style.backgroundColor = '#007a33';
        divElement.getElementsByClassName('m-button')[0].children[0].addEventListener('click', () => {
            const bufferLayer = map.getLayers().filter(layer => layer.type === 'BufferLayer');
            if (bufferLayer.length > 0) {
                const layerFeatures = CallGeoprontelImpl.getRenderedFeatures(bufferLayer[0]);
                const drawnGeometries = [];
                const centerCoordinates = []
                for (let i = 0; i < layerFeatures.length; i++) {
                    if (i % 2 === 0) {
                        centerCoordinates.push(layerFeatures[i].getGeometry());
                    } else {
                        drawnGeometries.push(layerFeatures[i].getGeometry());
                    }
                }

                let aux1 = this.callLocationUrls(drawnGeometries, locationUrls, map.getProjection().code, catastrowfsurl);
                const petitionsLocationUrls = aux1[0];
                const tiposUrl = aux1[1];

                let aux2 = this.callGeoprontelApi(map, apiGeoprontelUrl, selectedLayerIds,drawnGeometries);
                const petitionsApi = aux2[0];
                
                let aux3 = this.callGeoprontelOtherUrls(otherUrlsToGeoprontel);
                const petitionsOtherApi = aux3[0];

                //Muestra mensaje mientras carga la información. 
                M.dialog.info('Cargando información'); 
                // document.getElementsByClassName('m-button')[0].style.display="none";
                document.querySelector("#mapjs > div.m-dialog.info > div > div > div.m-button > button:nth-child(1)").style.display="none";
                //Añadir botón de cancelar
                const buttElement = document.getElementsByClassName('m-content');
                //Crear botón
                var tempButt = document.createElement("BUTTON");
                tempButt.id = "buttonCancel";
                tempButt.innerHTML = "Cancelar";  
                tempButt.style.width="auto";
                if (buttElement.length === 1){
                    buttElement[0].children[2].insertAdjacentElement('beforeend', tempButt);

                } else{
                    //Solución cuando sale doble popup
                    buttElement[1].children[2].insertAdjacentElement('beforeend', tempButt);
                }

                //Funcionalidad botón cancelar
                if(document.getElementById('buttonCancel')) {
                    document.getElementById('buttonCancel').addEventListener('click', () => {
                        if (document.getElementsByClassName('m-dialog')[0]) {
                            document.getElementsByClassName('m-dialog')[0].remove();
                        }
                        //ELIMINAR geometría
                        var obtenerPlg = map.getPlugins();
                        for (let i = 0; i < obtenerPlg.length; i++) {
                            if (obtenerPlg[i].name === 'buffer') {
                                obtenerPlg[i].control_.removeFeatures();
                            }
                        }
                    });
                }

                //Inicio de promesas
                let bandera1 = false;
                let bandera2 = false;
                let bandera3 = false;

                Promise.all(petitionsLocationUrls).then(values => {
                    // try{
                        const urlGroups = this.chunkifyFeatures(values, locationUrls.length);
                        const tiposGroups = this.chunkifyFeatures(tiposUrl, locationUrls.length);
                        let i = 0;
                        const layerNames = [];
                        const xmlToJson = [];
                        urlGroups.forEach(values => {
                            const layerIdName = 'Datos de localización de ' + tiposUrl[i].tipo.toString();
                            layerNames.push(layerIdName);
                            this.createTable();
                            this.removePreviousData(layerIdName);
                            const featuresPromises = this.obtainFeatureData(values, tiposGroups[i]);
                            const currentType = tiposUrl[i].tipo;
                            if(currentType === 'catastro') {
                                for(let geom = 0; geom < featuresPromises.length; geom++) {
                                    Promise.all(featuresPromises[geom]).then(geomFeats => {
                                        const features = this.extractFeatureDataFromCoordinates(geomFeats, currentType);
                                        xmlToJson.push(features);
                                        this.addLocationData(layerIdName, features, geom+1, currentType);
                                        if(geom === featuresPromises.length - 1) {
                                            this.addShowButton(layerIdName);
                                        }  
                                    });
                                }
                            } else {
                                for(let geom = 0; geom < featuresPromises.length; geom++) {
                                    const features = this.extractFeatureDataFromCoordinates(featuresPromises[geom], currentType);
                                    xmlToJson.push(features);
                                    this.addLocationData(layerIdName, features, geom+1, currentType);
                                    if(geom === featuresPromises.length - 1) {
                                        this.addShowButton(layerIdName);
                                    }
                                }
                            }
                            i++;
                        });

                        window.parent.postMessage({
                            results: xmlToJson
                        });
                                
                    bandera1 = true;
                    if(bandera2 === true && bandera3 === true){
                        if (document.getElementsByClassName('m-dialog info')[0]) {
                            document.getElementsByClassName('m-dialog info')[0].remove();
                        }
                    }

                })

                Promise.all(petitionsApi).then(values => {
                    // let j = 0;
                    if(values.toString().includes('HTTP 500')=== false || values.toString().includes('HTTP 400')=== false) {
                    // try{
                         values.forEach(value => {
                        // const layerIdName = layerIds[j];
                        const layerIdName = selectedLayerIds;
                        this.createTable();
                        this.removePreviousData(layerIdName);
                        const features = JSON.parse(value).features;
                        this.addFoundData(layerIdName, features, drawnGeometries.length, true, layerIdName);
                        this.addShowButton(layerIdName);
                        // j++;
                        });

                        window.parent.postMessage({
                            results: values
                        });
                    } else{
                    // } catch (err) { 
                        M.dialog.error("Se ha producido un error en la consulta.");
                        
                        document.getElementById('toggle-button').remove();
                        if (document.getElementsByClassName('m-dialog info')[0]) {
                            document.getElementsByClassName('m-dialog info')[0].remove();
                            
                            if (values.toString().includes('java.lang.OutOfMemoryError')) {
                                M.dialog.error('El área seleccionada es demasiado grande. Por favor, seleccione un área menor');
                            } else {
                                M.dialog.error('Error del servidor.');
                            }
                        //     //ELIMINAR geometría
                            var obtenerPlg = map.getPlugins();
                            for (let i = 0; i < obtenerPlg.length; i++) {
                                if (obtenerPlg[i].name === 'buffer') {
                                    obtenerPlg[i].control_.removeFeatures();
                                }
                            }
                        }
                    }
                   
                    bandera2 = true;
                    if(bandera1 === true && bandera3 === true){
                        if (document.getElementsByClassName('m-dialog info')[0]) {
                            document.getElementsByClassName('m-dialog info')[0].remove();
                        }
                    }
                });

                Promise.all(petitionsOtherApi).then(values => {
                    // try{
                        let k = 0;
                        const valuesCollector = [];
                        values.forEach(value => {
                            const layerName = `URL de Geoprontel ${k + 1}`;
                            const layerIdName = `urlGeoprontel${k + 1}`;
                            this.createTable();
                            this.removePreviousData(layerIdName);
                            const featuresRaw = JSON.parse(value.text).features;
                            const featureData = this.createFeatures(featuresRaw);
                            fetch(apiGeoprontelUrl, this.buildJsonFetch(drawnGeometries, featureData, map.getProjection().code)).then(response => response.json()).then(value => {
                                const features = value.features;
                                valuesCollector.push(features);
                                this.addFoundData(layerIdName, features, drawnGeometries.length, false, layerName);
                                this.addShowButton(layerIdName);
                            });
                            k++;
                        });

                        window.parent.postMessage({
                            results: valuesCollector
                        });
                    
                    bandera3 = true;
                    if(bandera1 === true && bandera2 === true){
                        if (document.getElementsByClassName('m-dialog info')[0]) {
                            document.getElementsByClassName('m-dialog info')[0].remove();
                        }
                    }
                });
            }
        });
    }

    static callLocationUrls(drawnGeometries, locationUrls, mapProjCode, catastrowfsurl) {
        const petitions = [];
        const tipos = [];
        for (let i = 0; i < drawnGeometries.length; i++) {
           
            const extent = drawnGeometries[i].getExtent();

            for (let j = 0; j < locationUrls.length; j++) {
                let currentUrl = locationUrls[j];
                if(currentUrl.includes('catastro')) {
                    petitions.push(M.remote.get(catastrowfsurl, {
                        service: "wfs",
                        request: "getFeature",
                        Typenames: "cp.cadastralparcel",
                        SRSname: mapProjCode,
                        bbox: extent.toString()
                      }));
                    const datosTipo = {};
                    datosTipo.rawUrl = currentUrl;
                    datosTipo.tipo = 'catastro';
                    tipos.push(datosTipo);
                }
                else if(currentUrl.includes('sipna')) {
                    const p0 = extent[0].toString() + ',' + extent[1].toString();
                    const p1 = extent[0].toString() + ',' + extent[3].toString();
                    const p2 = extent[2].toString() + ',' + extent[3].toString();
                    const p3 = extent[2].toString() + ',' + extent[1].toString();
                    const bboxPolygon = p0 + ' ' + p1 + ' ' + p2 + ' ' + p3 + ' ' + p0;
                    const urlMain = currentUrl.split('&FILTER=')[0];
                    const finalUrl = urlMain + '&FILTER=' + encodeURIComponent(filters.sipna.replace('BBOX', bboxPolygon));
                    petitions.push(M.remote.get(finalUrl));
                    const datosTipo = {};
                    datosTipo.rawUrl = currentUrl;
                    datosTipo.tipo = 'sipna';
                    tipos.push(datosTipo);
                }
                else if(currentUrl.includes('agriculturaypesca')) {
                    const p0 = extent[0].toString() + ',' + extent[1].toString();
                    const p1 = extent[0].toString() + ',' + extent[3].toString();
                    const p2 = extent[2].toString() + ',' + extent[3].toString();
                    const p3 = extent[2].toString() + ',' + extent[1].toString();
                    const bboxPolygon = p0 + ' ' + p1 + ' ' + p2 + ' ' + p3 + ' ' + p0;
                    const urlMain = currentUrl.split('&FILTER=')[0];
                    const finalUrl = urlMain + '&FILTER=' + encodeURIComponent(filters.agriculturaypesca.replace('BBOX', bboxPolygon));
                    petitions.push(M.remote.get(finalUrl));
                    const datosTipo = {};
                    datosTipo.rawUrl = finalUrl;
                    datosTipo.tipo = 'agriculturaypesca';
                    tipos.push(datosTipo);
                } else {
                    tipos.push('otras');
                }
            }
        }
        return [petitions, tipos];
    }

    static callGeoprontelApi(map, apiGeoprontelUrl, selectedLayerIds, drawnGeometries) {

        const layers = map.getLayers();
        const petitions = [];
        const tipos = [];
        if (selectedLayerIds !== 'Seleccione capa(s):'){
            layers.forEach(layer => {
                if ((selectedLayerIds.includes(layer.id) || selectedLayerIds.includes(layer.name)) && layer.isVisible()) {
                    //Se manda la info a la API
                    petitions.push(fetch(apiGeoprontelUrl, this.buildJsonFetch(drawnGeometries, layer.getFeatures(), map.getProjection().code)).then(response => response.text()));
                    tipos.push('api');
                }
            });
        }else{
            M.dialog.error('Seleccione una capa');
            //ELIMINAR geometría
            var obtenerPlg = map.getPlugins();
            for (let i = 0; i < obtenerPlg.length; i++) {
                if (obtenerPlg[i].name === 'buffer') {
                    obtenerPlg[i].control_.removeFeatures();
                }
            }
            
        }
        return [petitions, tipos];
    }

    static callGeoprontelOtherUrls(otherUrlsToGeoprontel) {
        const petitions = [];
        const tipos = [];
        otherUrlsToGeoprontel.forEach(url => {
            const featuresPetition = M.remote.get(url);
            petitions.push(featuresPetition);
            tipos.push('otrosApi');
        })
        return [petitions, tipos];
    }

    static createFeatures(featureRaw) {
        return featureRaw.map(f => new M.Feature('', f));
    }

    static buildJsonFetch(drawnGeometries, layerFeatures, code) {
        return {
            'headers': {
                'accept': 'application/json',
                'content-type': 'application/json'
            },
            'body': this.buildGeoprontelJson(drawnGeometries, layerFeatures, code),
            'method': 'POST'
        };
    }

    static buildGeoprontelJson(drawnGeometries, layerFeatures, code) {
        const json = {};
        json.geoproceso = 'grado_cobertura';
        json.name = 'GEOPRONTEL_ENTRADA';
        json.id = M.utils.generateRandom();
        json.capaBase = {};
        json.capaBase.epsg = code.split(':')[1];
        json.capaBase.parametros = [
            { 
                "nombreParametro": "buffer",
                "valorParametro": 0.1
            }
        ];
        json.capaBase.geometrias = [];
        drawnGeometries.forEach(geometry => {
            const geometria = {};
            geometria.type = 'Feature';
            geometria.id = `id_${M.utils.generateRandom()}`;
            geometria.geometry = {
                "type": geometry.getType(),
                "coordinates": geometry.getCoordinates()
            };
            geometria.properties = {};
            json.capaBase.geometrias.push(geometria);
        });
        json.capaFondo = {};
        json.capaFondo.epsg = code.split(':')[1];
        json.capaFondo.parametros = [
            {
                "nombreParametro": "buffer",
                "valorParametro": 0.1
            }
        ];
        json.capaFondo.geometrias = [];
        layerFeatures.forEach(feature => {
            const geometria = {};
            geometria.type = 'Feature';
            geometria.id = feature.getId();
            geometria.geometry = feature.getGeometry();
            geometria.properties = {};
            const property = {};
            property.datosProperties = 'buffer';
            property.valorProperty = 0.1;
            geometria.properties.datoProperties = [property];
            json.capaFondo.geometrias.push(geometria);
        });
        return JSON.stringify(json);
    }

    static chunkifyFeatures(promises, urlCount) {
        const result = [];
        for (let n = 0; n < urlCount; n++) {
            result.push([]);
        }
        for(let c = 0; c < promises.length; c++) {
            result[c % urlCount].push(promises[c]);
        }
        return result;
    }

    static createTable() {
        if (!document.getElementById('table')) {
            const div1 = document.createElement('div');
            div1.setAttribute('id', 'table');
            div1.setAttribute('class', 'hidden');
            const div2 = document.createElement('div');
            div2.setAttribute('id', 'toggle-button');
            const showButton = document.createElement('button');
            const initialClass = window.innerWidth > 768 ? 'g-cartografia-flecha-izquierda' : 'g-cartografia-flecha-arriba';
            showButton.setAttribute('class', initialClass);
            showButton.addEventListener('click', () => {
                const closed = window.innerWidth > 768 ? 'g-cartografia-flecha-izquierda' : 'g-cartografia-flecha-arriba';
                const opened = window.innerWidth > 768 ? 'g-cartografia-flecha-derecha' : 'g-cartografia-flecha-abajo';
                const tableDiv = document.getElementById('table');
                if (tableDiv.classList.contains("hidden")) {
                    tableDiv.classList.remove("hidden");
                    showButton.classList = "";
                    showButton.classList.add(opened);
                    showButton.parentNode.classList.add('toggle');
                    this.checkTableWidth();
                } else {
                    tableDiv.classList.add("hidden");
                    showButton.classList = "";
                    showButton.classList.add(closed);
                    showButton.parentNode.classList.remove('toggle');
                    showButton.parentNode.classList.remove('expanded');
                }
            });
            div2.appendChild(showButton);
            document.body.appendChild(div1);
            document.body.appendChild(div2);
        }
    }

    static removePreviousData(layerIdName) {
        const fatherElement = document.getElementById(layerIdName);
        if(fatherElement) {
            while (fatherElement.firstChild) {
                fatherElement.removeChild(fatherElement.lastChild);
            }
        }
    }

    static addFoundData(layerIdName, geoprontelFeatures, drawnGeometries, isLayerPresent, layerName) {
        const table = document.createElement('table');
        table.setAttribute('class', 'coverage-data');
        let dataElement = document.getElementById(layerIdName);
        const titleRow = document.createElement('tr');
        isLayerPresent ? titleRow.appendChild(this.createCell('Cobertura de capa: ' + layerName, true)) : titleRow.appendChild(this.createCell('Cobertura: ' + layerName, true));
        titleRow.firstChild.setAttribute('colspan', '2'); 
        titleRow.firstChild.setAttribute('class', 'table-header');
        table.appendChild(titleRow);
        const step = geoprontelFeatures.length / drawnGeometries;
        let count = 0;
        geoprontelFeatures.forEach(feature => {
            if(count % step === 0) {
                const titleRowFeat = document.createElement('tr');
                titleRowFeat.appendChild(this.createCell('Geometría ' + ((count / step)+1).toString(), true));
                titleRowFeat.firstChild.setAttribute('colspan', '2');
                titleRowFeat.setAttribute('class', 'hidden geomTitle');
                table.appendChild(titleRowFeat);
            } 
            count++;
            const propertiesData = feature.properties.datosProperties;
            const backgroundFeature = propertiesData.find(propertyData => propertyData.nombreProperty === 'idgFondo').valorProperty;
            const coveragePercentage = propertiesData.find(propertyData => propertyData.nombreProperty === 'coberturagFondogBase').valorProperty;            
            const row = document.createElement('tr');
            row.setAttribute('class', 'hidden ');
            row.appendChild(this.createCell(backgroundFeature, false));
            row.appendChild(this.createCell(coveragePercentage, false));
            table.appendChild(row);
        });
        if (!dataElement) {
            dataElement = document.createElement('div');
            dataElement.setAttribute('id', layerIdName);
        }
        dataElement.appendChild(table);
        document.getElementById('table').appendChild(dataElement);
    }

    static addLocationData(layerIdName, feats, geomCount, type) {
        let dataElement = document.getElementById(layerIdName);
        let newTable = false;
        if (!dataElement) {
            dataElement = document.createElement('div');
            dataElement.setAttribute('id', layerIdName);
        }
        let table = dataElement.getElementsByClassName('location-data')[0];
        if(!table) {
            table = document.createElement('table');
            table.setAttribute('class', 'location-data');
            const titleRow = document.createElement('tr');
            titleRow.appendChild(this.createCell(layerIdName, true));
            titleRow.firstChild.setAttribute('colspan', '2');
            titleRow.firstChild.setAttribute('class', 'table-header');
            table.appendChild(titleRow);
            newTable = true;
        }
        const titleRowGeom = document.createElement('tr');
        titleRowGeom.appendChild(this.createCell('Geometría ' + geomCount, true));
        titleRowGeom.firstChild.setAttribute('colspan', '2');
        titleRowGeom.setAttribute('class', 'hidden ');
        table.appendChild(titleRowGeom);
        let c = 1;
        feats.forEach(feature => {
            const titleRowFeat = document.createElement('tr');
            let typeStylized = '';
            if (type === 'catastro') {
                typeStylized = 'Parcela catastral';
            } else if (type === 'sipna') {
                typeStylized = 'Patrimonio Cultural';
            } else if (type === 'agriculturaypesca') {
                typeStylized = 'Parcela agrícola';
            }
            titleRowFeat.appendChild(this.createCell(typeStylized + ' ' + c, false));
            titleRowFeat.firstChild.setAttribute('colspan', '2');
            titleRowFeat.setAttribute('class', 'hidden');
            titleRowFeat.classList.add('subtitle');
            table.appendChild(titleRowFeat);
            for (const name in feature) {
                const propertyName  = name;
                const propertyData = feature[name];                
                const row = document.createElement('tr');
                const aux1 = this.createCell(propertyName, false);
                const aux2 = this.createCell(propertyData, false);
                row.setAttribute('class', 'hidden');
                aux1.setAttribute('class', 'location-attr');
                aux2.setAttribute('class', 'location-info');
                row.appendChild(aux1);
                row.appendChild(aux2);
                table.appendChild(row);
            }
            c++;
        });

        if (newTable) {
            dataElement.appendChild(table);
            document.getElementById('table').appendChild(dataElement);
        }
    }

    static createCell(content, isHeader) {
        const element = isHeader ? document.createElement("th") : document.createElement("td");
        element.appendChild(document.createTextNode(content));
        return element;
    }

    static obtainFeatureData(values, tipoJson) {
        const allFeats = [];
        for (let aux = 0; aux < values.length; aux++) {
            const urlFeats = [];
            if (tipoJson[aux].tipo === 'catastro') {
                const xmlDoc = new DOMParser().parseFromString(values[aux].text, 'text/xml');
                const members = xmlDoc.getElementsByTagName('member');
                for (let m = 0; m<members.length; m++) {
                    const coords = members[m].getElementsByTagName('gml:pos')[0].textContent;
                    const coordsVec = coords.split(' ');
                    let finalUrl = tipoJson[aux].rawUrl.replace('PART_X', coordsVec[0]).replace('PART_Y', coordsVec[1]);
                    urlFeats.push(M.remote.get(finalUrl));
                }
                allFeats.push(urlFeats);
            } else if (tipoJson[aux].tipo === 'sipna') {
                const xmlDoc = new DOMParser().parseFromString(values[aux].text, 'text/xml');
                const members = xmlDoc.getElementsByTagName('gml:featureMember');
                for (let m = 0; m<members.length; m++) {
                    const single = members[m].innerHTML;
                    urlFeats.push(single);
                }
                allFeats.push(urlFeats);
            } else if (tipoJson[aux].tipo === 'agriculturaypesca') {
                const jsonDoc = JSON.parse(values[aux].text);
                const members = jsonDoc.features;
                allFeats.push(members);
            }
        }
        return allFeats;
    }

    static extractFeatureDataFromCoordinates(values, tipo) {
        let features = [];
        values.forEach(value => {
            if(value.text !== null){
                switch (tipo) {
                    case 'catastro': {
                            const xmlDoc = new DOMParser().parseFromString(value.text, 'text/xml');
                            const ldt = xmlDoc.getElementsByTagName('ldt')[0].textContent;
                            const coordX = (xmlDoc.getElementsByTagName('xcen')[0].textContent) * 1;
                            const coordY = (xmlDoc.getElementsByTagName('ycen')[0].textContent) * 1;
                            const pc1 = xmlDoc.getElementsByTagName('pc1')[0].textContent;
                            const pc2 = xmlDoc.getElementsByTagName('pc2')[0].textContent;
                            const feat = {
                                'ldt': ldt,
                                'coorX': coordX,
                                'coorY': coordY,
                                'pc1': pc1,
                                'pc2': pc2
                            }                      
                        features.push(feat);
                        break;
                    }
                    case 'sipna': {
                        const xmlDoc = new DOMParser().parseFromString(value, 'text/xml');
                        const cod_ocupa = xmlDoc.getElementsByTagName('ms:cod_ocupa')[0].textContent;
                        const desc_ocupa = xmlDoc.getElementsByTagName('ms:desc_ocupa')[0].textContent;
                        const pgi = xmlDoc.getElementsByTagName('ms:pgi')[0].textContent;
                        const pct_arbo = xmlDoc.getElementsByTagName('ms:pct_arbo')[0].textContent;
                        const pct_mato = xmlDoc.getElementsByTagName('ms:pct_mato')[0].textContent;
                        const pct_herb = xmlDoc.getElementsByTagName('ms:pct_herb')[0].textContent;
                        const pct_suelo = xmlDoc.getElementsByTagName('ms:pct_suelo')[0].textContent;
                        const pct_querc = xmlDoc.getElementsByTagName('ms:pct_querc')[0].textContent;
                        const pct_conif = xmlDoc.getElementsByTagName('ms:pct_conif')[0].textContent;
                        const pct_euc = xmlDoc.getElementsByTagName('ms:pct_euc')[0].textContent;
                        const pct_ofron = xmlDoc.getElementsByTagName('ms:pct_ofron')[0].textContent;
                        const pct_culth = xmlDoc.getElementsByTagName('ms:pct_culth')[0].textContent;
                        const pct_cultl = xmlDoc.getElementsByTagName('ms:pct_cultl')[0].textContent;
                        const pct_citri = xmlDoc.getElementsByTagName('ms:pct_citri')[0].textContent;
                        const pct_olivar = xmlDoc.getElementsByTagName('ms:pct_olivar')[0].textContent;
                        const pct_vitis = xmlDoc.getElementsByTagName('ms:pct_vitis')[0].textContent;
                        const pct_ofrut = xmlDoc.getElementsByTagName('ms:pct_ofrut')[0].textContent;
                        const pct_agua = xmlDoc.getElementsByTagName('ms:pct_agua')[0].textContent;
                        const pct_edif = xmlDoc.getElementsByTagName('ms:pct_edif')[0].textContent;
                        const pct_vial = xmlDoc.getElementsByTagName('ms:pct_vial')[0].textContent;
                        const pct_zverdeu = xmlDoc.getElementsByTagName('ms:pct_zverdeu')[0].textContent;
                        const pct_zexver = xmlDoc.getElementsByTagName('ms:pct_zexver')[0].textContent;
                        const feat = {
                            'cod_ocupa': cod_ocupa,
                            'desc_ocupa': desc_ocupa,
                            'pgi': pgi,
                            'pct_arbo': pct_arbo,
                            'pct_mato': pct_mato,
                            'pct_herb': pct_herb,
                            'pct_suelo': pct_suelo,
                            'pct_querc': pct_querc,
                            'pct_conif': pct_conif,
                            'pct_euc': pct_euc,
                            'pct_ofron': pct_ofron,
                            'pct_culth': pct_culth,
                            'pct_cultl': pct_cultl,
                            'pct_citri': pct_citri,
                            'pct_olivar': pct_olivar,
                            'pct_vitis': pct_vitis,
                            'pct_ofrut': pct_ofrut,
                            'pct_agua': pct_agua,
                            'pct_edif': pct_edif,
                            'pct_vial': pct_vial,
                            'pct_zverdeu': pct_zverdeu,
                            'pct_zexver': pct_zexver
                        }
                        features.push(feat);
                        break;
                    }
                    case 'agriculturaypesca': {
                        const data = value.properties;
                        features.push(data);
                        break;
                    }
                    default:
                        break;
                }
            }   
        });
        return features;
    }

    static addShowButton(divName, index) {
        const tableDiv = document.getElementById(divName);
        const tableHeader = tableDiv.getElementsByClassName('table-header')[0];
        let header = tableHeader.parentNode;
        header.addEventListener('click', () => {
            if (!header.classList.contains('toggle')) {
                let row = header.nextSibling;
                while (row) {
                    if (row.firstChild.nodeName === 'TH') {
                        row.classList.remove('hidden');
                    }
                    row = row.nextSibling;
                }
                header.classList.add('toggle');
            } else {
                let row = header.nextSibling;
                while (row) { 
                    if (!row.classList.contains('hidden')) {
                        row.classList.add('hidden');
                    }
                    row = row.nextSibling;
                }
                header.classList.remove('toggle');
            }
            this.checkTableWidth();
        });
        const allRows = tableDiv.firstChild.childNodes;
        for (let r = 0; r < allRows.length; r++) {
            const cell = allRows[r].firstChild;
            if(cell.nodeName === 'TH' && !cell.classList.contains('table-header')) {
                cell.addEventListener('click', () => {
                    let normalRow = cell.parentNode.nextSibling;
                    while(normalRow && normalRow.firstChild.nodeName !== 'TH') {
                        if (normalRow.classList.contains('hidden')) {
                            normalRow.classList.remove('hidden');
                        } else {
                            normalRow.classList.add('hidden');
                        }
                        normalRow = normalRow.nextSibling;
                    }
                    this.checkTableWidth();
                });
            }
        }
    }

    static checkTableWidth() {
        const button = document.getElementById('toggle-button');
        const tableDiv = document.getElementById('table');
        if (tableDiv.offsetWidth > 305) {
            button.classList.replace('toggle', 'expanded');
        } else {
            button.classList.replace('expanded', 'toggle');
        }
    }
}
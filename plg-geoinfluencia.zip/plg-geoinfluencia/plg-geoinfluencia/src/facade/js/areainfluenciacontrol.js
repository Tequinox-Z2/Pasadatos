/**
 * @module M/control/AreainfluenciaControl
 */

import AreainfluenciaImplControl from 'impl/areainfluenciacontrol';

import 'assets/css/buffer.ol.min';
import './buffer.ol.min';

// import CallGeoprontel from './callgeoprontel';

export default class AreainfluenciaControl extends M.Control {
  /**
   * @classdesc
   * Main constructor of the class. Creates a PluginControl
   * control
   *
   * @constructor
   * @extends {M.Control}
   * @api stable
   */
  constructor(params) {
    // 1. checks if the implementation can create PluginControl
    if (M.utils.isUndefined(AreainfluenciaImplControl)) {
      M.exception('La implementación usada no puede crear controles AreainfluenciaControl');
    }
    // 2. implementation of this control
    const impl = new AreainfluenciaImplControl(params);
    super(impl, 'Areainfluencia');

    this.params_ = params || {};

    this.position_ = this.params_.position;
    this.collapsible_ = this.params_.collapsible;
    this.collapsed_ = this.params_.collapsed;
    
    this.apiGeoprontelUrl_ = this.params_.apiGeoprontelUrl;
    this.layerIds_ = this.params_.layerIds;
    // this.selectedLayerIds_ = this.params_.selectedLayerIds;
    this.otherUrlsToGeoprontel_ = this.params_.otherUrlsToGeoprontel;
    this.locationUrls_ = this.params_.locationUrls;
  }

  /**
   * This function creates the view
   *
   * @public
   * @function
   * @param {M.Map} map to add the control
   * @api stable
   */
  createView(map) {
    // if (!M.template.compileSync) { // JGL: retrocompatibilidad Mapea4
    //   M.template.compileSync = (string, options) => {
    //     let templateCompiled;
    //     let templateVars = {};
    //     let parseToHtml;
    //     if (!M.utils.isUndefined(options)) {
    //       templateVars = M.utils.extends(templateVars, options.vars);
    //       parseToHtml = options.parseToHtml;
    //     }
    //     const templateFn = Handlebars.compile(string);
    //     const htmlText = templateFn(templateVars);
    //     if (parseToHtml !== false) {
    //       templateCompiled = M.utils.stringToHtml(htmlText);
    //     } else {
    //       templateCompiled = htmlText;
    //     }
    //     return templateCompiled;
    //   };
    // }
    
    return new Promise((success, fail) => {
      // const mp = new M.plugin.Buffer({
      //   position: this.position_ ? this.position_ : 'TR',
      //   collapsible: this.collapsible_ ? this.collapsible_ : true,
      //   collapsed: this.collapsed_ ? this.collapsed_ : true
      // });
      
      // map.addPlugin(mp);

      // // Los valores de las variables “this.apiGeoprontelUrl_”, “this.layerIds_”, “this.otherUrlsToGeoprontel_” y “this.locationUrls_” se deben recoger en el constructor de la clase
      // CallGeoprontel.putEvents(map, this.apiGeoprontelUrl_, this.layerIds_, this.otherUrlsToGeoprontel_, this.locationUrls_);
      // selectedLayerIds
    });
  }

  /**
   * This function is called on the control activation
   *
   * @public
   * @function
   * @api stable
   */
  activate() {
    // calls super to manage de/activation
    super.activate();
  }
  /**
   * This function is called on the control deactivation
   *
   * @public
   * @function
   * @api stable
   */
  deactivate() {
    // calls super to manage de/activation
    super.deactivate();
  }
  /**
   * This function gets activation button
   *
   * @public
   * @function
   * @param {HTML} html of control
   * @api stable
   */
  getActivationButton(html) {
    return html.querySelector('.m-areainfluencia button');
  }

  /**
   * This function compares controls
   *
   * @public
   * @function
   * @param {M.Control} control to compare
   * @api stable
   */
  equals(control) {
    return control instanceof AreainfluenciaControl;
  }

  // Add your own functions
}

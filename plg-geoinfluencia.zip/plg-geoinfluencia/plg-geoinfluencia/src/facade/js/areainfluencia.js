/**
 * @module M/plugin/Areainfluencia
 */
 import 'assets/css/areainfluencia';
 import api from '../../api.json';
 import 'assets/css/buffer.ol.min';
 import './buffer.ol.min';
 import CallGeoprontel from './callgeoprontel';
 
 export default class Areainfluencia extends M.Plugin {
   /**
    * @classdesc
    * Main facade plugin object. This class creates a plugin object which has an implementation Object
    * @constructor
    * @extends {M.Plugin}
    * @param {Object} impl implementation object
    * @api stable
    */
   constructor(params) {
     super();
     /**
      * Facade of the map
      * @private
      * @type {M.Map}
      */
     this.map_ = null;
 
     /**
      * Array of controls
      * @private
      * @type {Array<M.Control>}
      */
     this.controls_ = [];
 
     /**
      * Metadata from api.json
      * @private
      * @type {Object}
      */
     this.metadata_ = api.metadata;
 
     this.params_ = params || {};
 
     this.position_ = this.params_.position;
     this.collapsible_ = this.params_.collapsible;
     this.collapsed_ = this.params_.collapsed;
     
     this.apiGeoprontelUrl_ = this.params_.apiGeoprontelUrl;
     this.layerIds_ = this.params_.layerIds;
     this.otherUrlsToGeoprontel_ = this.params_.otherUrlsToGeoprontel;
     this.locationUrls_ = this.params_.locationUrls;
     this.catastrowfsurl_ = this.params_.catastrowfsurl;
     this.name = 'areainfluencia';

     this.bufferPlugin = this.bufferPlugin = new M.plugin.Buffer({
      position: this.position_ ? this.position_ : 'TR',
      collapsible: this.collapsible_ ? this.collapsible_ : true,
      collapsed: this.collapsed_ ? this.collapsed_ : true
    });
   }
 
   /**
    * This function adds this plugin into the map
    *
    * @public
    * @function
    * @param {M.Map} map the map to add the plugin
    * @api stable
    */
   addTo(map) {
     this.map_ = map;
     this.panel_ = new M.ui.Panel('panelAreainfluencia', {
       collapsible: true,
       position: M.ui.position.TR,
       collapsedButtonClass: 'g-cartografia-flecha-izquierda',
     });
     this.panel_.addControls(this.controls_);
     
     map.addPlugin(this.bufferPlugin);
     this.bufferPlugin.control_.on(M.evt.ADDED_TO_MAP, () => {
      this.fire(M.evt.ADDED_TO_MAP);
    });
 
     CallGeoprontel.putEvents(map, this.apiGeoprontelUrl_, this.layerIds_, this.otherUrlsToGeoprontel_, this.locationUrls_, this.catastrowfsurl_);

    //  CallGeoprontel.putEvents(map, this.apiGeoprontelUrl_, this.selectedLayerIds_, this.otherUrlsToGeoprontel_, this.locationUrls_, this.catastrowfsurl_);
   }
 
   /**
    * This function gets metadata plugin
    *
    * @public
    * @function
    * @api stable
    */
   getMetadata(){
     return this.metadata_;
   }
 }
 
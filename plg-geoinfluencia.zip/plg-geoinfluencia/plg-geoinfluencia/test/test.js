import Areainfluencia from 'facade/areainfluencia';

// M.proxy(false);


const map = M.map({
  container: 'mapjs',
  controls: ['layerswitcher'],
});

// const lyProvincias = new M.layer.WFS({
//   legend: "Campamentos",
//   url: "http://geostematicos-sigc.juntadeandalucia.es/geoserver/wfs",
//   namespace: "sepim",
//   name: "campamentos",
//   geometry: 'POINT',
//   extract: true
// });
// map.addLayers(lyProvincias);

// const lyProvincias2 = new M.layer.WFS({
//   legend: "Provincias centroides",
//   url: "http://geostematicos-sigc.juntadeandalucia.es/geoserver/wfs",
//   namespace: "tematicos",
//   name: "provincias_pob_centroides",
//   geometry: 'POINT',
//   extract: true
// });
// map.addLayers(lyProvincias2);

// const lyProvincias20 = new M.layer.WFS({
//   legend: "ehoteleros",
//   url: "http://geostematicos-sigc.juntadeandalucia.es/geoserver/wfs",
//   namespace: "sepim",
//   name: "ehoteleros",
//   geometry: 'POINT',
//   extract: true
// });
// map.addLayers(lyProvincias20);

// const lyProvincias3 = new M.layer.WFS({
//   legend: "Provincias",
//   url: "http://geostematicos-sigc.juntadeandalucia.es/geoserver/tematicos/ows",
//   namespace: "tematicos",
//   name: "Provincias",
//   geometry: 'POLYGON',
//   extract: true
// });
// map.addLayers(lyProvincias3);

var lyProvincias3 = new M.layer.GeoJSON({
  name: "Provincias", 
  url: "http://geostematicos-sigc.juntadeandalucia.es/geoserver/tematicos/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=tematicos:Provincias&maxFeatures=50&outputFormat=application/json",
  extract: false
});
map.addLayers(lyProvincias3);

/*const mp = new Areainfluencia({
 apiGeoprontelUrl: 'https://www.juntadeandalucia.es/medioambiente/serviciosGeoprontel/geoproceso',
            // layerIds: ['Provincias'],
            layerIds: ['campamentos', 'provincias_pob_centroides', 'Provincias'],
            locationUrls: ['https://ws128.juntadeandalucia.es/agriculturaypesca/geoserver218/wfs?request=GetFeature&service=WFS&version=1.0.0&typeName=PARCELAS_ACTUAL&outputFormat=JSON&FILTER=%3CFilter%20xmlns=%22http://www.opengis.net/ogc%22%20xmlns:gml=%22http://www.opengis.net/gml%22%3E%3CIntersects%3E%3CPropertyName%3ESD_GEOM%3C/PropertyName%3E%3Cgml:Point%20srsName=%22EPSG:25830%22%3E%3Cgml:coordinates%3EPART_X,PART_Y%3C/gml:coordinates%3E%3C/gml:Point%3E%3C/Intersects%3E%3C/Filter%3E'
            ,'https://ovc.catastro.meh.es/ovcservweb/OVCSWLocalizacionRC/OVCCoordenadas.asmx/Consulta_RCCOOR?Coordenada_X=PART_X&Coordenada_Y=PART_Y&SRS=EPSG:25830'
           ],
		otherUrlsToGeoprontel: [],
		catastrowfsurl: 'http://ovc.catastro.meh.es/INSPIRE/wfsCP.aspx?'
});*/

/*const mp = new Areainfluencia({
		apiGeoprontelUrl: 'https://www.juntadeandalucia.es/medioambiente/serviciosGeoprontel/geoproceso',
		layerIds: [],
		locationUrls: [],
		otherUrlsToGeoprontel: ['https://www.juntadeandalucia.es/medioambiente/mapwms/REDIAM_WFS_Patrimonio_Natural?service=WFS&request=getFeature&version=2.0.0&outputformat=geojson&typename=humedales_ramsar']
	  });*/

    const mp = new Areainfluencia({
      apiGeoprontelUrl: 'https://servpruebas.cma.junta-andalucia.es/medioambiente/serviciosGeoprontel/geoproceso',
      layerIds: [],
      locationUrls: ['https://ws128.juntadeandalucia.es/agriculturaypesca/geoserver218/wfs?request=GetFeature&service=WFS&version=1.0.0&typeName=PARCELAS_ACTUAL&outputFormat=JSON&FILTER=%3CFilter%20xmlns=%22http://www.opengis.net/ogc%22%20xmlns:gml=%22http://www.opengis.net/gml%22%3E%3CIntersects%3E%3CPropertyName%3ESD_GEOM%3C/PropertyName%3E%3Cgml:Point%20srsName=%22EPSG:25830%22%3E%3Cgml:coordinates%3EPART_X,PART_Y%3C/gml:coordinates%3E%3C/gml:Point%3E%3C/Intersects%3E%3C/Filter%3E'],
      otherUrlsToGeoprontel: []
      });

map.addPlugin(mp);

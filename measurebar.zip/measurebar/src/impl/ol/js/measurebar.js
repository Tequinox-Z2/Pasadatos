goog.provide('P.impl.plugin.Measurebar');

goog.require('P.impl.control.MeasureLength');
goog.require('P.impl.control.MeasureArea');
goog.require('P.impl.control.MeasureClear');
goog.require('P.plugin.Measurebar');

// this file it is just used in order to imports
var myMap;

function init() {
	
	myMap = M.map({
		container: "mapjs",
		controls: ['scale', 'scaleline', 'mouse', 'overviewmap']
	});
	
	M.config.panels.TOOLS = [];
	
	var scaleConfig = {
		scales: [1000, 2000, 5000, 10000, 25000, 50000, 100000, 150000, 250000, 500000, 1000000, 2000000]
	};

	var navigationPlugin = new M.plugin.Navigation({
		measureLength: true,
		measureArea: true,
		geocalc: false,
		identify: {
			all: false, 
			byLayer:[]
		},
		catastroSearch: {
			add: false, 
			config: null
		},
		scale: {
			add: true,
			config: scaleConfig
		},
		coordinatesZoom: false
	});

	myMap.addPlugin(navigationPlugin);
}
